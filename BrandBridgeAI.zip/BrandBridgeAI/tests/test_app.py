"""End-to-end tests. Run with:  python -m pytest -v

Covers the 15 required scenarios plus security checks. No external AI service is used.
"""
import io
import os
import sys

import fitz
import pytest
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app  # noqa: E402
from config import TestConfig  # noqa: E402
from extensions import db  # noqa: E402
from models import (AuditLog, ContentIssue, ContentSubmission, CorrectionSuggestion, Organisation, Review,  # noqa: E402
                    RevisionHistory, User)

DEMO_TEXT = ("ABC Tech offers the world's best software with 100% guaranteed results. "
             "Buy now and become successful instantly.")
GUIDELINE = {
    "title": "ABC Guidelines", "company_name": "ABC Technologies", "tone_style": "friendly",
    "description": "Business software.", "voice_tone": "Professional and friendly.",
    "approved_terms": "ABC Technologies | ABC Tech, ABC Tech Ltd",
    "prohibited_words": "cheap => affordable\nguru => expert",
    "unsupported_claims": "100% guaranteed results => a focus on quality results",
    "brand_colours": "#2563EB, #0F172A, #FFFFFF",
    "slogans": "Technology That Moves You Forward",
    "facts": "ABC Technologies was founded in 2015. | Company profile\nABC Technologies serves over 500 business customers. | Annual report",
    "is_active": "on",
}


@pytest.fixture()
def app(tmp_path):
    class Cfg(TestConfig):
        UPLOAD_FOLDER = str(tmp_path / "uploads")
    application = create_app(Cfg)

    @application.before_request
    def _isolate_login_cache():
        # tests keep one app context open, so Flask-Login's per-request user cache on `g` must be reset
        from flask import g
        g.pop("_login_user", None)

    with application.app_context():
        db.create_all()
        yield application
        db.session.remove()
        db.drop_all()


def register(client, **kw):
    data = {"name": "Test User", "email": "u@example.com", "password": "Passw0rd!", "confirm": "Passw0rd!",
            "mode": "create", "org_name": "ABC Technologies", "invite_code": ""}
    data.update(kw)
    return client.post("/register", data=data, follow_redirects=True)


def login(client, email, password="Passw0rd!"):
    return client.post("/login", data={"email": email, "password": password}, follow_redirects=True)


@pytest.fixture()
def world(app):
    """Org with admin, creator, reviewer (each with its own client) and one guideline."""
    admin, creator, reviewer = app.test_client(), app.test_client(), app.test_client()
    register(admin, name="Admin", email="admin@x.com")
    org = Organisation.query.first()
    register(creator, name="Creator", email="creator@x.com", mode="join", invite_code=org.invite_code, org_name="")
    register(reviewer, name="Reviewer", email="reviewer@x.com", mode="join", invite_code=org.invite_code, org_name="")
    rev_user = User.query.filter_by(email="reviewer@x.com").first()
    r = admin.post(f"/settings/users/{rev_user.id}/role", data={"role": "reviewer"}, follow_redirects=True)
    assert b"Manager / Reviewer" in r.data
    r = admin.post("/guidelines/new", data=GUIDELINE, follow_redirects=True)
    assert b"Brand guideline created" in r.data
    return {"app": app, "admin": admin, "creator": creator, "reviewer": reviewer}


def submit(client, text=DEMO_TEXT, title="Launch post", ctype="advert", **files):
    data = {"title": title, "content_type": ctype, "content_text": text, "image_alt": ""}
    data.update(files)
    return client.post("/content/submit", data=data, content_type="multipart/form-data", follow_redirects=False)


def latest_sub():
    return ContentSubmission.query.order_by(ContentSubmission.id.desc()).first()


# ---------------------------------------------------------------- 1 & 2: registration / login
def test_01_user_can_register(app):
    c = app.test_client()
    r = register(c)
    assert b"Welcome to BrandBridge AI" in r.data
    u = User.query.filter_by(email="u@example.com").first()
    assert u and u.role == "admin" and u.password_hash != "Passw0rd!"  # hashed, not stored in plain text


def test_01b_duplicate_and_weak_registration(app):
    register(app.test_client())
    r = register(app.test_client(), org_name="Other Org")
    assert r.status_code == 400 and b"already exists" in r.data
    r = register(app.test_client(), email="b@example.com", password="short", confirm="short")
    assert r.status_code == 400 and b"at least 8" in r.data
    r = register(app.test_client(), email="c@example.com", mode="join", invite_code="NOPE")
    assert r.status_code == 400 and b"Invalid invite code" in r.data


def test_02_user_can_login_and_logout(app):
    register(app.test_client())
    c = app.test_client()
    assert b"Invalid email or password" in login(c, "u@example.com", "wrong-pass").data
    assert b"Dashboard" in login(c, "u@example.com").data
    r = c.post("/logout", follow_redirects=True)
    assert b"signed out" in r.data
    assert c.get("/dashboard").status_code == 302  # session gone


# ---------------------------------------------------------------- 3: guidelines
def test_03_admin_can_manage_guidelines(world):
    admin = world["admin"]
    assert b"ABC Guidelines" in admin.get("/guidelines/").data
    from models import BrandGuideline
    g = BrandGuideline.query.first()
    assert len(g.facts) == 2 and g.brand_colours.startswith("#2563EB")
    r = admin.post(f"/guidelines/{g.id}/edit", data={**GUIDELINE, "title": "Renamed"}, follow_redirects=True)
    assert b"Renamed" in r.data
    r = admin.post("/guidelines/new", data={**GUIDELINE, "brand_colours": "not-a-colour"})
    assert r.status_code == 400 and b"not a valid hex colour" in r.data
    r = admin.post(f"/guidelines/{g.id}/delete", follow_redirects=True)
    assert b"Guideline deleted" in r.data and BrandGuideline.query.count() == 0


def test_03b_missing_guidelines_handled(app):
    c = app.test_client()
    register(c)
    r = submit(c)
    assert r.status_code == 400 and b"No brand guidelines" in r.data


# ---------------------------------------------------------------- 4-8: submission + checker
def test_04_user_can_submit_content_and_status_is_not_approved(world):
    r = submit(world["creator"])
    assert r.status_code == 302
    sub = latest_sub()
    assert sub.status == "checked"       # AI/rules never auto-approve
    assert sub.score is not None and sub.checked_version == 1


def test_04b_empty_and_invalid_submissions(world):
    c = world["creator"]
    assert b"Content is empty" in submit(c, text="").data
    assert b"valid content type" in submit(c, ctype="bogus").data
    assert b"content title" in submit(c, title="").data


def test_05_checker_identifies_prohibited_word(world):
    submit(world["creator"], text="Our cheap tool helps ABC Technologies customers.")
    titles = {(i.title, i.original_text) for i in latest_sub().current_issues()}
    assert ("Prohibited word or phrase", "cheap") in titles
    sug = next(i.suggestion for i in latest_sub().current_issues() if i.original_text == "cheap")
    assert sug.suggested_text == "affordable"


def test_06_unsupported_claim_without_evidence_flagged_and_evidence_respected(world):
    submit(world["creator"], text="ABC Technologies is the #1 choice for small business software.")
    issues = latest_sub().current_issues()
    claim = next(i for i in issues if i.rule_id == "promo-rank-one")
    assert claim.verification == "needs_human_verification"
    assert "No approved supporting fact" in claim.related_source
    # now add approved evidence -> claim is no longer flagged
    from models import ApprovedFact, BrandGuideline
    g = BrandGuideline.query.first()
    g.facts.append(ApprovedFact(statement="Ranked #1 in SME software satisfaction by Example Survey 2026.", source="Survey"))
    db.session.commit()
    submit(world["creator"], text="ABC Technologies is the #1 choice for small business software.", title="again")
    assert not any(i.rule_id == "promo-rank-one" for i in latest_sub().current_issues())


def test_06b_fact_conflict_vs_unverified_are_distinct(world):
    submit(world["creator"], text="ABC Technologies was founded in 2012. We are ISO 9001 certified.")
    by_rule = {i.rule_id: i for i in latest_sub().current_issues()}
    assert by_rule["fact-conflict"].verification == "conflicts_with_approved_fact"
    assert "2015" in by_rule["fact-conflict"].related_source
    assert by_rule["fact-unverified"].verification == "needs_human_verification"
    assert "false" not in by_rule["fact-unverified"].explanation.lower().replace("not necessarily wrong", "")


def test_07_08_issues_are_explained_and_corrections_generated(world):
    submit(world["creator"])
    issues = latest_sub().current_issues()
    names = {i.title for i in issues}
    assert {"Incorrect company / product name", "Unsupported claim listed in guidelines",
            "Unrealistic outcome promise", "Unsupported superlative claim", "Pushy call-to-action"} <= names
    for i in issues:
        assert i.explanation and i.guideline_violated and i.suggested_correction and i.severity in ("High", "Medium", "Low")
        assert i.suggestion is not None
    name_issue = next(i for i in issues if i.title == "Incorrect company / product name")
    assert name_issue.original_text == "ABC Tech" and name_issue.suggestion.suggested_text == "ABC Technologies"


def test_results_page_shows_score_explanation_and_actions(world):
    submit(world["creator"])
    r = world["creator"].get(f"/content/{latest_sub().id}")
    assert r.status_code == 200
    for needle in (b"Brand Compliance Score", b"not a certified or objective measure", b"Accept", b"Reject",
                   b"Edit manually", b"Needs Human Verification", b"Violated guideline"):
        assert needle in r.data, needle


# ---------------------------------------------------------------- 9-12: workflow
def _first_pending(sub):
    return next(i.suggestion for i in sub.current_issues() if i.suggestion.suggested_text is not None
                and i.suggestion.status == "pending")


def test_09_creator_edits_and_resubmits(world):
    c = world["creator"]
    submit(c)
    sub = latest_sub()
    # accept every automatic suggestion
    for s in [i.suggestion for i in sub.current_issues() if i.suggestion.suggested_text is not None]:
        r = c.post(f"/content/{sub.id}/suggestion/{s.id}/accept", follow_redirects=True)
        assert r.status_code == 200
    db.session.refresh(sub)
    assert "ABC Technologies offers" in sub.content_text and "world's best" not in sub.content_text
    assert sub.version > 1 and not sub.is_check_current
    # cannot send before re-checking
    r = c.post(f"/content/{sub.id}/send-review", follow_redirects=True)
    assert b"Re-run the brand check" in r.data
    # manual edit + automatic re-check
    new_text = sub.content_text + " Our support team is friendly."
    r = c.post(f"/content/{sub.id}/edit", data={"content_text": new_text}, follow_redirects=True)
    assert b"updated and re-checked" in r.data
    db.session.refresh(sub)
    assert sub.is_check_current and sub.score > 80
    r = c.post(f"/content/{sub.id}/send-review", follow_redirects=True)
    assert b"Sent to a manager" in r.data
    db.session.refresh(sub)
    assert sub.status == "pending_review"
    # locked now
    assert c.post(f"/content/{sub.id}/edit", data={"content_text": "x"}, follow_redirects=True).status_code == 200
    db.session.refresh(sub)
    assert sub.content_text == new_text


def test_09b_reject_and_manual_edit_of_suggestion(world):
    c = world["creator"]
    submit(c)
    sub = latest_sub()
    issues = [i for i in sub.current_issues() if i.suggestion.suggested_text is not None]
    c.post(f"/content/{sub.id}/suggestion/{issues[0].suggestion.id}/reject", follow_redirects=True)
    assert issues[0].suggestion.status == "rejected"
    target = next(i for i in issues[1:] if i.suggestion.original_text in sub.content_text)
    c.post(f"/content/{sub.id}/suggestion/{target.suggestion.id}/edit", data={"custom_text": "MY OWN WORDING"})
    db.session.refresh(sub)
    assert "MY OWN WORDING" in sub.content_text and target.suggestion.status == "edited"
    events = [r.event for r in sub.revisions]
    assert "suggestion_rejected" in events and "suggestion_edited" in events


def _to_pending(world):
    c = world["creator"]
    submit(c)
    sub = latest_sub()
    assert c.post(f"/content/{sub.id}/send-review", follow_redirects=True).status_code == 200
    db.session.refresh(sub)
    assert sub.status == "pending_review"
    return sub


def test_10_manager_can_request_changes_then_creator_resubmits(world):
    sub = _to_pending(world)
    rv = world["reviewer"]
    assert b"Submissions waiting" in rv.get("/reviews").data
    r = rv.post(f"/reviews/{sub.id}/decide", data={"decision": "changes_requested", "comment": ""}, follow_redirects=True)
    assert b"comment is required" in r.data
    r = rv.post(f"/reviews/{sub.id}/decide", data={"decision": "changes_requested", "comment": "Remove the guarantee."},
                follow_redirects=True)
    assert b"Changes requested" in r.data
    db.session.refresh(sub)
    assert sub.status == "changes_requested"
    c = world["creator"]
    assert b"Remove the guarantee." in c.get(f"/content/{sub.id}").data
    c.post(f"/content/{sub.id}/edit", data={"content_text": "ABC Technologies offers quality software."}, follow_redirects=True)
    c.post(f"/content/{sub.id}/send-review", follow_redirects=True)
    db.session.refresh(sub)
    assert sub.status == "pending_review"


def test_11_manager_can_approve_or_reject(world):
    sub = _to_pending(world)
    rv = world["reviewer"]
    r = rv.post(f"/reviews/{sub.id}/decide", data={"decision": "approved", "comment": "Good to go."}, follow_redirects=True)
    assert b"Content approved" in r.data
    db.session.refresh(sub)
    assert sub.status == "approved"
    # a decided submission cannot be decided again
    r = rv.post(f"/reviews/{sub.id}/decide", data={"decision": "rejected", "comment": "no"}, follow_redirects=True)
    assert b"pending review" in r.data
    # reject path
    c = world["creator"]
    submit(c, title="second")
    s2 = latest_sub()
    c.post(f"/content/{s2.id}/send-review")
    rv.post(f"/reviews/{s2.id}/decide", data={"decision": "rejected", "comment": "Off-brand."})
    db.session.refresh(s2)
    assert s2.status == "rejected"


def test_12_review_history_is_saved(world):
    sub = _to_pending(world)
    world["reviewer"].post(f"/reviews/{sub.id}/decide", data={"decision": "approved", "comment": "OK"})
    rv = Review.query.filter_by(submission_id=sub.id).one()
    assert rv.decision == "approved" and rv.comment == "OK" and rv.reviewer.email == "reviewer@x.com"
    assert rv.created_at is not None and rv.content_version == sub.version
    events = [r.event for r in RevisionHistory.query.filter_by(submission_id=sub.id).order_by(RevisionHistory.id)]
    assert events[0] == "submitted" and "check_run" in events and "sent_for_review" in events and events[-1] == "review_approved"
    assert b"OK" in world["reviewer"].get("/history").data
    assert b"Original submission" in world["creator"].get(f"/content/{sub.id}/revisions").data
    first = RevisionHistory.query.filter_by(submission_id=sub.id).first()
    from markupsafe import escape
    assert str(escape(DEMO_TEXT)).encode() in world["creator"].get(f"/content/{sub.id}/revisions/{first.id}").data
    assert AuditLog.query.filter_by(action="review.approved").count() == 1


# ---------------------------------------------------------------- 13: analytics from DB
def test_13_dashboard_displays_real_database_statistics(world):
    c, rv = world["creator"], world["reviewer"]
    submit(c, title="A")
    a = latest_sub()
    submit(c, title="B", text="Friendly clean copy from ABC Technologies.")
    b = latest_sub()
    c.post(f"/content/{b.id}/send-review")
    rv.post(f"/reviews/{b.id}/decide", data={"decision": "approved", "comment": "ok"})
    data = rv.get("/analytics/data").get_json()
    assert data["totals"]["submissions"] == 2 and data["totals"]["approved"] == 1
    assert data["totals"]["issues"] == ContentIssue.query.filter_by(is_current=True).count()
    assert data["totals"]["high"] == ContentIssue.query.filter_by(is_current=True, severity="High").count()
    assert sum(data["monthly"]["submissions"]) == 2 and sum(data["monthly"]["reviews"]) == 1
    assert data["common_mistakes"] and data["score_trend"]["values"]
    page = rv.get("/dashboard")
    assert page.status_code == 200 and b"Approved" in page.data
    # an empty organisation shows zeros, not sample numbers
    other = world["app"].test_client()
    register(other, email="o@x.com", org_name="Empty Org")
    assert other.get("/analytics/data").get_json()["totals"]["submissions"] == 0


# ---------------------------------------------------------------- 14: access control
def test_14_unauthorised_access_is_blocked(world):
    app, creator, reviewer = world["app"], world["creator"], world["reviewer"]
    anon = app.test_client()
    for url in ("/dashboard", "/guidelines/", "/content/submit", "/reviews", "/analytics", "/settings", "/history"):
        assert anon.get(url).status_code == 302, url
    assert creator.get("/guidelines/new").status_code == 403
    assert creator.post("/guidelines/new", data=GUIDELINE).status_code == 403
    assert reviewer.get("/guidelines/new").status_code == 403
    assert reviewer.get("/content/submit").status_code == 403
    assert creator.get("/reviews/1").status_code == 403
    assert creator.post("/reviews/1/decide", data={"decision": "approved"}).status_code == 403
    assert creator.post("/settings/users/1/role", data={"role": "admin"}).status_code == 403
    sub = _to_pending(world)
    # another creator in the same org cannot see this creator's submission
    c2 = app.test_client()
    register(c2, email="c2@x.com", mode="join", invite_code=Organisation.query.first().invite_code, org_name="")
    assert c2.get(f"/content/{sub.id}").status_code == 404
    assert c2.get(f"/files/sub-image/{sub.id}").status_code == 404
    # a user from a different organisation cannot see it either
    outsider = app.test_client()
    register(outsider, email="out@y.com", org_name="Other Co")
    assert outsider.get(f"/content/{sub.id}").status_code == 404
    assert outsider.post(f"/reviews/{sub.id}/decide", data={"decision": "approved", "comment": "x"}).status_code == 404
    # creators cannot approve their own content by any route
    assert creator.post(f"/reviews/{sub.id}/decide", data={"decision": "approved"}).status_code == 403
    db.session.refresh(sub)
    assert sub.status == "pending_review"


def test_14b_reviewer_cannot_review_own_submission(world):
    admin = world["admin"]
    submit(admin, title="admin post")  # admins can also submit
    sub = latest_sub()
    admin.post(f"/content/{sub.id}/send-review")
    r = admin.post(f"/reviews/{sub.id}/decide", data={"decision": "approved", "comment": "self"}, follow_redirects=True)
    assert b"cannot review your own" in r.data
    db.session.refresh(sub)
    assert sub.status == "pending_review"


def test_14c_csrf_protection_enforced(tmp_path):
    class Cfg(TestConfig):
        WTF_CSRF_ENABLED = True
        UPLOAD_FOLDER = str(tmp_path / "u")
    application = create_app(Cfg)
    with application.app_context():
        db.create_all()
        r = application.test_client().post("/login", data={"email": "a@b.com", "password": "x"})
        assert r.status_code == 302  # CSRF error handler redirects; nothing was processed
        assert User.query.count() == 0
        db.drop_all()


# ---------------------------------------------------------------- 15: works without AI
def test_15_works_without_external_ai(world):
    assert world["app"].config["AI_PROVIDER"] == "none"
    submit(world["creator"])
    sub = latest_sub()
    assert "not configured" in sub.ai_status and all(i.source == "rule" for i in sub.current_issues())
    assert sub.current_issues()


def test_15b_failed_ai_request_degrades_gracefully(world, monkeypatch):
    import ai_service
    app = world["app"]
    app.config.update(AI_PROVIDER="anthropic", AI_API_KEY="dummy")

    def boom(*a, **k):
        import requests
        raise requests.ConnectionError("offline")
    monkeypatch.setattr(ai_service.requests, "post", boom)
    r = submit(world["creator"])
    assert r.status_code == 302
    sub = latest_sub()
    assert "AI review unavailable" in sub.ai_status and sub.current_issues()


def test_15c_ai_findings_are_validated(world, monkeypatch):
    import ai_service
    app = world["app"]
    app.config.update(AI_PROVIDER="openai", AI_API_KEY="dummy")
    payload = '{"issues":[{"title":"Hype","category":"Tone Consistency","severity":"Low","original_text":"Buy now","explanation":"x","guideline":"voice","suggested_text":"Learn more","needs_human_verification":false},' \
              '{"title":"Invented","category":"Tone Consistency","severity":"High","original_text":"text that is not in the content","explanation":"x","guideline":"g","suggested_text":null},' \
              '{"title":"BadCat","category":"Nonsense","severity":"High","original_text":"world","explanation":"x","guideline":"g"}]}'

    class Resp:
        status_code = 200
        def raise_for_status(self): pass
        def json(self): return {"choices": [{"message": {"content": payload}}]}
    monkeypatch.setattr(ai_service.requests, "post", lambda *a, **k: Resp())
    findings, status = ai_service.ai_review(app.config, "Join us. Hello world! Wow", __import__("checker").BrandProfile(company_name="X"), "advert", [])
    assert [f.original_text for f in findings] == []  # "Buy now" not in text, others invalid
    findings, status = ai_service.ai_review(app.config, "Please buy now. Hello world", __import__("checker").BrandProfile(company_name="X"), "advert", [])
    assert status.startswith("AI review completed") and findings == []  # case mismatch is discarded (verbatim only)
    findings, _ = ai_service.ai_review(app.config, "Please Buy now. Hello world", __import__("checker").BrandProfile(company_name="X"), "advert", [])
    assert len(findings) == 1 and findings[0].source == "ai" and findings[0].original_text == "Buy now"


# ---------------------------------------------------------------- uploads
def _png(color=(37, 99, 235), size=(200, 120)):
    buf = io.BytesIO()
    Image.new("RGB", size, color).save(buf, "PNG")
    buf.seek(0)
    return buf


def _pdf(text):
    doc = fitz.open()
    page = doc.new_page()
    page.insert_text((72, 72), text)
    data = doc.tobytes()
    return io.BytesIO(data)


def test_upload_validation(world):
    c = world["creator"]
    bad_pdf = (io.BytesIO(b"this is not a pdf"), "fake.pdf")
    r = submit(c, text="", pdf=bad_pdf)
    assert r.status_code == 400 and b"not a valid PDF" in r.data
    r = submit(c, image=(io.BytesIO(b"not an image"), "x.png"))
    assert r.status_code == 400 and b"not a valid image" in r.data
    r = submit(c, image=(io.BytesIO(b"<svg onload=alert(1)>"), "x.svg"))
    assert r.status_code == 400 and b"Unsupported image format" in r.data
    r = submit(c, text="", pdf=(io.BytesIO(b"x"), "doc.exe"))
    assert r.status_code == 400 and b"Only PDF" in r.data
    big = io.BytesIO(b"%PDF-" + b"0" * (11 * 1024 * 1024))
    r = submit(c, text="", pdf=(big, "big.pdf"))
    assert r.status_code in (302, 400)  # either too large for the request or for the PDF limit
    assert ContentSubmission.query.count() == 0
    assert os.listdir(world["app"].config["UPLOAD_FOLDER"]) == [] if os.path.exists(world["app"].config["UPLOAD_FOLDER"]) else True


def test_pdf_extraction_and_checking(world):
    c = world["creator"]
    r = submit(c, text="", ctype="pdf", pdf=(_pdf("Our cheap software is great."), "brochure.pdf"))
    assert r.status_code == 302
    sub = latest_sub()
    assert "cheap" in sub.content_text and sub.pdf_filename
    assert any(i.original_text == "cheap" for i in sub.current_issues())
    # file is only available to authorised users, never via a static URL
    assert c.get(f"/files/sub-pdf/{sub.id}").status_code == 200
    assert world["app"].test_client().get(f"/files/sub-pdf/{sub.id}").status_code == 302
    assert c.get(f"/uploads/{sub.pdf_filename}").status_code == 404


def test_visual_checker_logo_colours_and_alt_text(world):
    admin, c = world["admin"], world["creator"]
    from models import BrandGuideline
    g = BrandGuideline.query.first()
    logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sample_data", "abc_logo_approved.png")
    if not os.path.exists(logo_path):
        import seed
        seed.make_samples()
    with open(logo_path, "rb") as fh:
        data = {**GUIDELINE, "logo": (io.BytesIO(fh.read()), "logo.png")}
    r = admin.post(f"/guidelines/{g.id}/edit", data=data, content_type="multipart/form-data", follow_redirects=True)
    assert b"updated" in r.data
    # exact approved logo -> no logo issue
    with open(logo_path, "rb") as fh:
        submit(c, text="Hello from ABC Technologies.", title="logo ok", image=(io.BytesIO(fh.read()), "l.png"))
    rules = {i.rule_id for i in latest_sub().current_issues()}
    assert "visual-logo" not in rules and "a11y-image-alt" in rules  # alt text still missing
    # off-brand image -> colour + logo flagged, both as "needs human verification"
    off = os.path.join(os.path.dirname(logo_path), "banner_off_brand.png")
    with open(off, "rb") as fh:
        submit(c, text="Hello from ABC Technologies.", title="off brand", image=(io.BytesIO(fh.read()), "b.png"))
    issues = {i.rule_id: i for i in latest_sub().current_issues()}
    assert "visual-colour" in issues and "visual-logo" in issues
    assert issues["visual-logo"].verification == "needs_human_verification"
    # adding alt text on edit removes the accessibility issue
    sub = latest_sub()
    c.post(f"/content/{sub.id}/edit", data={"content_text": sub.content_text, "image_alt": "Red and green sale banner"})
    assert "a11y-image-alt" not in {i.rule_id for i in latest_sub().current_issues()}


# ---------------------------------------------------------------- checker unit tests
def test_checker_tone_accessibility_and_slogan(app):
    import checker
    p = checker.BrandProfile(company_name="ABC Technologies", tone_style="formal",
                             slogans=["Technology That Moves You Forward"])
    f = checker.check_text("We're gonna do it lol! AMAZING DEALS!! <img src='a.png'> click here. "
                           "Technology that moves you forwards.", p, "website")
    rules = {x.rule_id for x in f}
    assert {"tone-slang", "tone-contraction", "tone-caps", "a11y-img-alt", "a11y-link", "slogan-variant"} <= rules


def test_checker_clean_text_scores_100(app):
    import checker
    p = checker.BrandProfile(company_name="ABC Technologies", tone_style="professional",
                             approved_terms=[("ABC Technologies", [])])
    f = checker.check_text("ABC Technologies helps teams manage their projects.", p)
    assert f == [] and checker.compute_score(f)["score"] == 100


def test_score_formula(app):
    import checker

    class F:
        def __init__(self, s, v="none"): self.severity, self.verification = s, v
    r = checker.compute_score([F("High"), F("Medium"), F("Low"), F("Medium", "needs_human_verification")])
    assert r["score"] == 100 - (15 + 7 + 3 + 4)
    assert checker.compute_score([F("High")] * 10)["score"] == 0
